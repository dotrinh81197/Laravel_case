@extends('layout.admin')

@section('content_dashboard')

<div class="container">
<h1>TẠO HỢP ĐỒNG BẢO HIỂM ĐIỆN TỬ</h1>
<a href="{{route('contract.create')}}" class="btn btn-success">TẠO HỢP ĐỒNG</a>
</div>
@endsection