<div class="container-fuild" >
    <h3>Ví dụ minh họa cho sản phẩm {{$product->name}}</h3>
    <img src="{{ asset($product->illustration) }}" alt="ví dụ minh họa" width="100%">
</div> 