<div class="container-fuild" width:100%>
    <table></table>
{!!$product->benefit!!}
</div>